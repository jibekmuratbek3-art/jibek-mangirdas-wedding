JIBEK & MANGIRDAS WEDDING WEBSITE

Publish: create a free public GitHub repository, upload index.html, then Settings > Pages > Deploy from a branch > main /root > Save. Wait for the pages URL.

RSVP: FormSubmit sends to Jibekmuratbek7@outlook.com only after its email activation is confirmed. Submit a test RSVP from the live website, confirm the FormSubmit activation email in Outlook (including junk), then submit another test and verify delivery.

The HTML preview inside ChatGPT is NOT a reliable test for external form submission.
